//FIGHTS
Crafty.c("Moveable", {
    at: function (x, y) {
        if (x === undefined && y === undefined) {
            return { x: this.x, y: this.y}
        } else {
            this.attr({ x: x, y: y });
            return this;
        }
    }
})

Crafty.c("PowerBar", {
    init: function () {
        this.requires("2D, Color, Moveable");
        this.attr({ x: (Game.width() / 2) - 30, y: 26, z: 1, w: 0, h: 10 })
            .color("#fff")
        this.border = Crafty.e("2D, Canvas, DOM, Moveable");
        this.border.attr({ x: (Game.width() / 2) - 30, y: 24, z: 0, w: 81, h: 12 })
//            .color("#000000")
        this.border.css("border-style","solid")
        this.border.css("border-width","1px")
        this.border.css("border-radius","5px")
        this.border.css("webkit-border-radius","5px")

    },

    powerBar: function (speed) {
        this.attr({ x: (Game.width() / 2) - 30, y: 26, z: 1, w: speed, h: 10 })
        return this;
    },

    color: function(color) {
        this.color(color)
        return this
    }

});

Crafty.c("LifeBar", {
    init: function () {
        this.requires("2D, Color, Canvas")
            .color("#006600")
        this.background = Crafty.e("2D, Color, Canvas")
        .color("#660000")
        .attr({ z: 0, w: 200, h: 10 })
    },

    life: function (life) {
        this.attr({ z: 1, w: life, h: 10 })
        return this;
    },

    color: function(color) {
        this.color(color)
        return this
    },
    at: function (x, y) {
        if (x === undefined && y === undefined) {
            return {x: this.x, y: this.y}
        } else {
            this.attr({ x: x, y: y });
            this.background.attr({ x: x, y: y });
            return this;
        }
    }

});

Crafty.c("Turret", {
    init: function () {
        this.requires("2D,Canvas,Moveable").origin(3, 8)
        this.attr({fireEnabled: false})
        this.weapons = {}
        this.selectedWeapon = null
        this.canShoot = false
        this.increasePower = false
        this.maxPower = 80
        this.currentPower = 0
        this.projectileOffset = {
            x: -20,
            y: 0
        }
        this.facingRight = true
    },
    sprite: function (spriteName) {
        this.addComponent(spriteName)
    },

    robot: function (robot) {
        if (typeof robot == "undefined") {
            return this.robot
        }
        this.robot = robot
    },

    incrementPower: function () {
        if (this.currentPower < this.maxPower) {
            this.currentPower++;
        } else {
            this.currentPower = 0;
        }
    },

    playerControlled: function (enable) {

        if (enable) {
            var self = this
            this.humanPlayer = true
        } else {
            this.humanPlayer = false
        }
    },

    canFire: function (fireEnabled) {
        if (typeof(fireEnabled) === "undefined") {
            return this.fireEnabled
        }
        this.fireEnabled = !!fireEnabled
    },

    addWeapon: function (name, weapon) {
        weapon.setTurret(this)
        this.weapons[name] = (weapon)
    },

    getWeapon: function (name) {
        return this.weapons[name]
    },

    getSelectedWeapon: function () {
        return this.selectedWeapon
    },
    setSelectedWeapon: function (name) {
        this.selectedWeapon = this.weapons[name];
    },

    getAngle: function () {
        return (this.rotation * Math.PI) / 200;
    },

    getInitialProjectileLocation: function () {
        var self = this
        var location = {
            x: self.x + self.projectileOffset.x,
            y: self.y + self.projectileOffset.y
        }
        return location
    },

    fire: function () {
        var self = this
        if (self.canShoot) {
            var box2d
            var sprite;
            var weapon = this.getSelectedWeapon()
            /*

             if (selectedShape === 1) {
             sprite = 'square'
             box2d = {
             bodyType: 'dynamic',
             density: 12,
             friction: 0.01,
             restitution: 0.3
             }
             }
             else if (selectedShape === 2) {
             sprite = 'penta'
             box2d = {
             bodyType: 'dynamic',
             density: 20,
             friction: 0.5,
             restitution: 0.3,
             shape: [
             [10, 0],
             [20, 8],
             [16, 20],
             [4, 20],
             [0, 8]
             ]
             }
             } else if (selectedShape === 3) {
             sprite = 'triangle'
             box2d = {
             bodyType: 'dynamic',
             density: 25,
             friction: 0.2,
             restitution: 0.3,
             shape: [
             [20, 0],
             [20, 20],
             [0, 20]
             ]
             }
             }
             */
            var projectile = weapon.fire();

            var onShapeEnterFrame = function () {
                if (!projectile.isMoving() || projectile.isOutsideOfWidth() || projectile.isMovingTooSlowly()) {
                    projectile.selfDestroy();
                    self.currentPower = 0;
                    this.unbind("EnterFrame", onShapeEnterFrame);
                    currentShape = null;
                    Scenes.game.fights.FIRST_STAGE.nextTurn()
                }
            }

            projectile.bind("EnterFrame", onShapeEnterFrame);
            this.robot.deActivate()
        }
    }

})

Crafty.c("RobotBody", {
    init: function () {
        this.requires("2D,Canvas,Moveable,Box2D");
    },

    sprite: function (name) {
        this.addComponent(name)
    },

    name: function () {
        return this.robotName
    },

    robot: function (robot) {
        if (typeof robot == "undefined") {
            return this.containerRobot
        }
        this.containerRobot = robot
        return this;
    }
})


Crafty.c("Robot", {

    init: function () {
        this.addComponent("Armor,Box2D,Collision,Solid")
        this.body = Crafty.e("RobotBody").robot(this);
        this.turret = Crafty.e("Turret");
        this.canShoot = false
        this.turret.robot(this)
        this.bodyOffset = {x: 0, y: -20}
        this.turretOffset = {x: 5, y: -60}
        this.humanPlayer = false
    },
    at: function (x, y) {
        this.body.at(x + this.bodyOffset.x, y + this.bodyOffset.y)
        this.turret.at(x + this.turretOffset.x, y + this.turretOffset.y)
    },

    name: function (name) {

        if (typeof name == "undefined") {
            return this.body.robotName
        }
        this.body.robotName = name
    },

    playerControlled: function (enable) {
        if (typeof enable == "undefined") {
            return this.humanPlayer
        }
        this.humanPlayer = true
        this.turret.playerControlled(enable);
    },

    activate: function () {
        if (this.isAlive()) {
            this.isActivated = true
            this.turret.canShoot = true
            if (!this.playerControlled()) {
                var rotation = getRandomInt(40, 70)
                var power = getRandomInt(40, this.turret.maxPower - 10)
                this.turret.rotation = rotation
                this.turret.currentPower = power
                this.turret.fire()
            }

        }
    },

    deActivate: function () {
        this.isActivated = false
        this.turret.canShoot = false
    },

    rotateTurret: function (x, y) {
        var shotPos = Crafty.DOM.translate(x, y);
        var rotation = (Math.atan2(shotPos.y - this.turret.y, shotPos.x - this.turret.x) * (180 / Math.PI));
        if (rotation > 0) {
            rotation = 0;
        } else if (rotation < -90) {
            rotation = -90;
        }

        this.turret.rotation = rotation;
    },

    increaseTurretPower: function () {
        this.turret.incrementPower()
    },

    fire: function () {
        this.turret.fire()
    }



})

Crafty.c("Armor", {
    init: function () {
        this.hitPoints = 200
    },
    takeHit: function (damage) {
        this.hitPoints -= damage
    },
    isAlive: function () {
        return this.hitPoints > 0
    }
})


Crafty.c("RobotTito", {
    init: function () {
        this.requires("Robot")
        this.body.sprite("tito_body_standing")
        this.turret.sprite("tito_canon")
        this.bodyOffset = {x: 0, y: -68}
        this.turretOffset = {x: 42, y: -44}
        this.name("Tito")
    }
})

Crafty.c("RobotLapachox", {
    init: function () {
        this.requires("Robot")
        this.body.sprite("lapachox_body_standing")
        this.turret.sprite("lapachox_canon")
        this.bodyOffset = {x: 0, y: -68}
        this.turretOffset = {x: 6, y: -41}
        this.name("Lapachox")
        this.turret.facingRight = false
    }
})

Crafty.c("Weapon", {
    init: function () {
        this.shape = null
        this.damage = 50

        //default values
        this.box2dAttributes = {
            bodyType: 'dynamic',
            density: 12,
            friction: 0.01,
            restitution: 0.3
        }

    },

    ammo: function (ammo) {
        if (typeof ammo == "undefined") {
            return this.ammoLeft
        }
        this.ammoLeft = ammo
    },

    setBox2dAttributes: function (attrs) {
        this.box2dAttributes = attrs
    },

    setProjectileDensity: function (newDensity) {
        this.box2dAttributes.density = newDensity
    },

    setProjectileFriction: function (newFriction) {
        this.box2dAttributes.friction = newFriction
    },

    setProjectileShape: function (sprite) {
        this.projectileShape = sprite
    },

    setBox2dShape: function (shape) {
        this.box2dAttributes.shape = shape
    },

    createProjectile: function (location) {
        var projectile = Crafty.e("Box2D, Canvas, Collision," + this.projectileShape)
            .attr(location)
//            .attr({ x: (40 + 25.5) - 10, y: (stage_h - 30) - 10, z: 0})
            .box2d(this.box2dAttributes)
        projectile.body.SetBullet(true);
        projectile.isMoving = function () {
            return this.body.IsAwake()
        }
        projectile.isMovingTooSlowly = function () {
            return Math.abs(this.body.m_linearVelocity.x) < 0.1
        }
        projectile.isOutsideOfWidth = function () {
            return ((this.x > Game.width() + 20 && this.y > Game.height()) || (this.x < -20 && this.y > Game.height()))
        }

        projectile.selfDestroy = function () {
            Crafty.box2D.world.DestroyBody(this.body);
            this.destroy()
        }

        projectile.onHit('RobotBody', function (data) {
            var robotHit = data[0].obj.robot()
            var robotThatFired = Scenes.game.fights.FIRST_STAGE.activeRobot
            var weaponUsed = robotThatFired.turret.getSelectedWeapon()

            if (robotHit.name() != robotThatFired.name()) {
                robotHit.hitPoints -= weaponUsed.damage
                this.selfDestroy()
                Scenes.game.fights.FIRST_STAGE.nextTurn()
            }
        })
        return projectile
    },

    setTurret: function (turret) {
        this.turret = turret
    },

    calculateImpulse: function () {
        var angleInRadians = this.turret.getAngle()
        var vx = Math.cos(angleInRadians) * (this.turret.currentPower + 40);
        var vy = Math.sin(angleInRadians) * (this.turret.currentPower + 40);
        if (this.turret.facingRight) {
            var impulse = new b2Vec2(vx, vy);
        } else {
            var impulse = new b2Vec2(-vx, -vy);
        }

        return impulse
    },

    fire: function () {

        var impulse = this.calculateImpulse()
        var location = this.turret.getInitialProjectileLocation()
        this.ammoLeft--
        currentShape = this.createProjectile(location)
        currentShape.body.ApplyImpulse(impulse, currentShape.body.GetWorldCenter());
        return currentShape;
    }

})

Crafty.c("TitoWeapon", {
    init: function () {
        this.requires("Weapon");
        this.setProjectileDensity(30)
        this.setProjectileFriction(1000)
        this.setProjectileShape('ball_spr')
        this.damage = 30
        var shape = "circle"
        this.setBox2dShape(shape)
        this.ammo(100)
    }
})

Crafty.c("LogWeapon", {
    init: function () {
        this.requires("Weapon");
        this.setProjectileDensity(22)
        this.setProjectileFriction(0.2)
        this.setProjectileShape('log_projectile')
        this.damage = 20
        /*var shape = []
        this.setBox2dShape(shape)*/
        this.ammo(100)
    }
})

Crafty.c("WoodenCrate", {
    init: function(){
        this.requires("2D, Canvas, Box2D,small_crate_spr")
/*            .attr({x: 200, y: Game.height() - 32})
            .box2d(
            {
                bodyType: 'dynamic',
                density: 15.0,
                friction: 10,
                restitution: 0

            })*/
    },
    at: function (x, y) {
        if (x === undefined && y === undefined) {
            return { x: this.x, y: this.y}
        } else {
            this.attr({ x: x, y: y - 32 });
            this.box2d(
                {
                    bodyType: 'dynamic',
                    density: 7.0,
                    friction: 10,
                    restitution: 0

                })
            return this;
        }
    }

})