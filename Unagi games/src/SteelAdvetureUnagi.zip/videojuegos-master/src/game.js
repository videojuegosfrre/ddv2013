Game = {
    ptm_ratio: 32,
    map_grid: {
        width:  24,
        height: 16,
        tile: {
            width:  32,
            height: 32
        }
    },

    width: function() {
        return this.map_grid.width * this.map_grid.tile.width;
    },

    height: function() {
        return this.map_grid.height * this.map_grid.tile.height;
    },



    // Initialize and start our game
    start: function() {
        Crafty.audio.add("click", "assets/audio/_click.ogg");
        // Start crafty and set a background color so that we can see it's working
        Crafty.init(Game.width(), Game.height());
        Crafty.box2D.init(0, 10, Game.ptm_ratio, true);
//        Crafty.box2D.showDebugInfo();
        Crafty.scene('Loading')
    }
}

$text_css = { 'font-size': '24px', 'font-family': 'Arial', 'color': 'white', 'text-align': 'center' }

function getRandomInt (min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

if (!String.prototype.format) {
    String.prototype.format = function() {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function(match, number) {
            return typeof args[number] != 'undefined'
                ? args[number]
                : match
                ;
        });
    };
}