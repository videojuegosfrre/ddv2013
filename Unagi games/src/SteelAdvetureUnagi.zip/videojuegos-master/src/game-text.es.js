TEXT = {
    MAIN_MENU: {
        NEW_GAME: 'Nuevo Juego'
    },
    FIGHT_COMMON: {
        SHOOTING_INSTRUCTION: 'Manten pulsado el boton del mouse para disparar.',
        PICK_A_WEAPON: 'Elije un arma',
        PIZZAS_REMAINING: 'Quedan {0} esferas',
        PEPPERONI_REMAINING: 'Quedan {0} Bombas ',
        BOXES_REMAINING: 'Quedan {0} Cajas'
    }

}