Scenes = {}
Scenes.menus = {
    MAIN_MENU: 'MainMenu'
}
Scenes.game = {
    FOREST_MAP: {
        INITIAL: 'ForestMapInitial',
        U1: 'ForestMapU1'
    },
    fights: {
        FIRST_STAGE: {
            name: 'FirstStageFight',
            floor: {}
        }
    }
}
Scenes.LOADING = 'Loading'

Crafty.scene(Scenes.game.FOREST_MAP.U1, function(){
    for (var i = 0; i < Game.map_grid.width; i++) {
        for (var j = 0; j < Game.map_grid.height; j++) {
            Crafty.e(Components.map.GRASS.SHORT_GRASS).at(i, j)
        }
    }

    overAxis('y').from(9).to(15).x(14).create(Components.map.LEDGE.RIGHT)
    Crafty.e(Components.map.LEDGE.TOP_RIGHT).at(14, 9)
    overAxis('x').from(8).to(13).y(9).create(Components.map.LEDGE.TOP)
    Crafty.e(Components.map.LEDGE.LEFT).at(7, 10)
    Crafty.e(Components.map.LEDGE.TOP_LEFT).at(7, 9)
    Crafty.e(Components.map.LEDGE.BOTTOM_LEFT).at(7, 11)
    overAxis('x').from(8).to(11).y(11).create(Components.map.LEDGE.BOTTOM)
    Crafty.e(Components.map.LEDGE.CLIFF_LEFTMOST).at(7,12)
    Crafty.e(Components.map.LEDGE.CLIFF_LEFTMOST_BOTTOM).at(7,13)
    overAxis('x').from(8).to(11).y(12).create(Components.map.LEDGE.CLIFF_CENTER)
    overAxis('x').from(8).to(11).y(13).create(Components.map.LEDGE.CLIFF_CENTER_BOTTOM)
    overAxis('y').from(12).to(14).x(12).create(Components.map.LEDGE.LEFT)
    overAxis('x').from(5).to(11).y(15).create(Components.map.LEDGE.TOP)
    overAxis('y').from(7).to(14).x(4).create(Components.map.LEDGE.RIGHT)
    Crafty.e(Components.map.LEDGE.TOP_RIGHT).at(4,6)
    overAxis('x').from(0).to(3).y(6).create(Components.map.LEDGE.TOP)


    Crafty.e(Components.map.TREE.TREE_LIGHT_GREEN_64).at(16, 14)
    overAxis('y').from(13).to(14).x(17).create(Components.map.TREE.TREE_GREEN_64)
    overAxis('y').from(12).to(14).x(18).create(Components.map.TREE.TREE_GREEN_64)
    overAxis('y').from(11).to(14).x(19).create(Components.map.TREE.TREE_LIGHT_GREEN_64)
    overAxis('y').from(10).to(14).x(20).create(Components.map.TREE.TREE_LIGHT_GREEN_64)
    overAxis('y').from(9).to(14).x(21).create(Components.map.TREE.TREE_GREEN_64)
    Crafty.e(Components.map.TREE.TREE_LIGHT_GREEN_64).at(19, 5)
    overAxis('y').from(8).to(14).x(22).create(Components.map.TREE.TREE_LIGHT_GREEN_64)
    Crafty.e(Components.map.TREE.TREE_DARK_GREEN_64).at(17, 3)
    Crafty.e(Components.map.TREE.TREE_DARK_GREEN_64).at(20, 2)
    Crafty.e(Components.map.TREE.TREE_DARK_GREEN_64).at(22, 1)
    Crafty.e(Components.map.TREE.TREE_LIGHT_GREEN_64).at(7, 5)
    Crafty.e(Components.map.TREE.TREE_LIGHT_GREEN_64).at(0, 2)
    Crafty.e(Components.map.TREE.TREE_DARK_GREEN_64).at(1, 4)
    Crafty.e(Components.map.TREE.TREE_LIGHT_GREEN_64).at(0, 0)
    Crafty.e(Components.map.TREE.TREE_LIGHT_GREEN_64).at(2, 0)
    Crafty.e(Components.map.TREE.TREE_GREEN_64).at(6, 0)
    Crafty.e(Components.map.TREE.TREE_GREEN_64).at(4, 1)
    Crafty.e(Components.map.TREE.TREE_GREEN_64).at(8, 0)
    Crafty.e(Components.map.TREE.TREE_GREEN_64).at(10, 0)
    Crafty.e(Components.map.TREE.TREE_DARK_GREEN_64).at(12, 1)
    Crafty.e(Components.map.TREE.TREE_DARK_GREEN_64).at(14, 2)
    Crafty.e(Components.map.TREE.TREE_DARK_GREEN_64).at(14, 0)
    Crafty.e(Components.map.TREE.TREE_GREEN_64).at(16, 1)
    Crafty.e(Components.map.TREE.TREE_GREEN_64).at(18, 0)
    Crafty.e(Components.map.TREE.TREE_DARK_GREEN_64).at(13, 5)
    Crafty.e(Components.map.STUMP_32).at(20, 7)
    Crafty.e(Components.map.STUMP_32).at(20, 8)
    Crafty.e(Components.map.STUMP_32).at(21, 7)
    Crafty.e(Components.map.STUMP_32).at(23, 6)
    Crafty.e(Components.map.STUMP_32).at(22, 6)
    Crafty.e(Components.map.STUMP_32).at(21, 6)
    Crafty.e(Components.map.STUMP_32).at(21, 5)
    Crafty.e(Components.map.STUMP_32).at(21, 4)
    Crafty.e(Components.map.STUMP_32).at(17, 9)
    Crafty.e(Components.map.STUMP_32).at(18, 11)
    Crafty.e(Components.map.GROUND_DECORATION_32).at(12, 5)
    Crafty.e(Components.map.GROUND_DECORATION_32).at(9, 8)
    Crafty.e(Components.map.GROUND_DECORATION_32).at(15, 8)
    Crafty.e(Components.map.GROUND_DECORATION_32).at(22, 3)


    Crafty.e(Components.map.FLOWERS_YELLOW_BIG_128).at(0, 6)
    Crafty.e(Components.map.HERB_LARGE_32).at(3, 6)
    Crafty.e(Components.map.HERB_LARGE_32).at(3, 7)
    Crafty.e(Components.map.HERB_MEDIUM_32).at(0, 8)
    Crafty.e(Components.map.TREE.TALL_TREE).at(0, 12)
    Crafty.e(Components.map.TREE.TALL_TREE).at(1, 12)
    Crafty.e(Components.map.TREE.TALL_TREE).at(0, 13)
    Crafty.e(Components.map.TREE.TALL_TREE).at(1, 13)
    Crafty.e(Components.map.TREE.TALL_TREE).at(0, 14)
    Crafty.e(Components.map.TREE.TALL_TREE).at(1, 14)
    Crafty.e(Components.map.TREE.TALL_TREE).at(14, 12)
    Crafty.e(Components.map.TREE.TALL_TREE).at(14, 14)
    Crafty.e(Components.map.ROCK_32_BROWN_32).at(14, 9)
    Crafty.e(Components.map.FLOWERS_YELLOW_BIG_128).at(7, 10)
    Crafty.e(Components.map.GRASS.TOP_LEFT_CORNER).at(1,10)
    Crafty.e(Components.map.GRASS.TOP_RIGHT_CORNER).at(2,10)
    Crafty.e(Components.map.GRASS.BOTTOM_LEFT_CORNER).at(1,11)
    Crafty.e(Components.map.GRASS.BOTTOM_RIGHT_CORNER).at(2,11)
    Crafty.e(Components.map.HERB_MEDIUM_32).at(3, 11)
    Crafty.e(Components.map.HERB_SINGLE_32).at(0, 11)
    Crafty.e(Components.map.HERB_SINGLE_32).at(0, 10)
    this.player = Crafty.e(Components.map.PLAYER).at(15, 15);
    Crafty.e(Components.map.SCENE_GO).to(Scenes.game.fights.FIRST_STAGE.name).at(11, 14)
    Crafty.e(Components.map.FIGHT_GUY).at(11, 14)
})

Crafty.scene(Scenes.game.FOREST_MAP.INITIAL, function () {

    for (var i = 0; i < Game.map_grid.width; i++) {
        for (var j = 0; j < Game.map_grid.height; j++) {
            Crafty.e(Components.map.GRASS.SHORT_GRASS).at(i, j)
        }
    }
    Crafty.e(Components.map.TREE.TREE_GREEN_64).at(16, 0)
    overAxis('y').from(0).to(1).x(17).create(Components.map.TREE.TREE_GREEN_64)
    overAxis('y').from(0).to(2).x(18).create(Components.map.TREE.TREE_GREEN_64)
    overAxis('y').from(0).to(3).x(19).create(Components.map.TREE.TREE_LIGHT_GREEN_64)
    overAxis('y').from(0).to(4).x(20).create(Components.map.TREE.TREE_LIGHT_GREEN_64)
    overAxis('y').from(0).to(5).x(21).create(Components.map.TREE.TREE_GREEN_64)
    Crafty.e(Components.map.TREE.TREE_LIGHT_GREEN_64).at(19, 5)
    overAxis('y').from(0).to(6).x(22).create(Components.map.TREE.TREE_LIGHT_GREEN_64)
    Crafty.e(Components.map.TREE.TREE_LIGHT_GREEN_64).at(17, 3)
    Crafty.e(Components.map.TREE.TREE_GREEN_64).at(17, 5)
    Crafty.e(Components.map.TREE.TREE_GREEN_64).at(18, 7)
    Crafty.e(Components.map.TREE.TREE_GREEN_64).at(18, 7)
    Crafty.e(Components.map.TREE.TREE_LIGHT_GREEN_64).at(18, 9)
    Crafty.e(Components.map.TREE.TREE_DARK_GREEN_64).at(14, 10)
    Crafty.e(Components.map.TREE.TREE_DARK_GREEN_64).at(13, 12)
    Crafty.e(Components.map.TREE.TREE_DARK_GREEN_64).at(11, 10)
    Crafty.e(Components.map.TREE.TREE_DARK_GREEN_64).at(16, 8)
    Crafty.e(Components.map.TREE.TREE_GREEN_64).at(7, 8)
    Crafty.e(Components.map.TREE.TREE_GREEN_64).at(16, 14)



    Crafty.e(Components.map.STUMP_32).at(20, 10)
    Crafty.e(Components.map.STUMP_32).at(20, 8)
    Crafty.e(Components.map.LOG_HOLLOW_32).at(21, 7)
    overAxis('y').from(8).to(12).x(23).create(Components.map.STUMP_32)
    overAxis('y').from(8).to(11).x(22).create(Components.map.STUMP_32)
    overAxis('y').from(8).to(10).x(21).create(Components.map.STUMP_32)
    overAxis('x').from(19).to(21).y(11).create(Components.map.STUMP_32)
    overAxis('x').from(17).to(22).y(12).create(Components.map.STUMP_32)
    overAxis('x').from(18).to(23).y(13).create(Components.map.STUMP_32)
    overAxis('x').from(22).to(23).y(14).create(Components.map.STUMP_32)


    Crafty.e(Components.map.LEDGE.RIGHT).at(14, 0)
    Crafty.e(Components.map.LEDGE.RIGHT).at(14, 1)
    Crafty.e(Components.map.LEDGE.BOTTOM_RIGHT).at(14, 2)
    overAxis('x').from(5).to(13).y(2).create(Components.map.LEDGE.BOTTOM)
    Crafty.e(Components.map.LEDGE.CLIFF_RIGHTMOST).at(14, 3)
    Crafty.e(Components.map.LEDGE.CLIFF_RIGHTMOST_BOTTOM).at(14, 4)
    overAxis('x').from(5).to(13).y(3).create(Components.map.LEDGE.CLIFF_CENTER)
    overAxis('x').from(5).to(13).y(4).create(Components.map.LEDGE.CLIFF_CENTER_BOTTOM)
    overAxis('y').from(3).to(7).x(4).create(Components.map.LEDGE.RIGHT)
    Crafty.e(Components.map.LEDGE.BOTTOM_RIGHT).at(4, 8)
    Crafty.e(Components.map.LEDGE.CLIFF_RIGHTMOST).at(4, 9)
    Crafty.e(Components.map.LEDGE.CLIFF_RIGHTMOST_BOTTOM).at(4, 10)
    overAxis('y').from(9).to(12).x(3).create(Components.map.LEDGE.RIGHT)
    Crafty.e(Components.map.LEDGE.BOTTOM_RIGHT).at(3, 13)
    overAxis('x').from(0).to(2).y(13).create(Components.map.LEDGE.BOTTOM)
    Crafty.e(Components.map.LEDGE.CLIFF_RIGHTMOST).at(3, 14)
    Crafty.e(Components.map.LEDGE.CLIFF_RIGHTMOST_BOTTOM).at(3, 15)
    overAxis('x').from(0).to(2).y(14).create(Components.map.LEDGE.CLIFF_CENTER)
    overAxis('x').from(0).to(2).y(15).create(Components.map.LEDGE.CLIFF_CENTER_BOTTOM)

    Crafty.e(Components.map.FLOWERS_YELLOW_BIG_128).at(0, 2)
    Crafty.e(Components.map.ROCK_32_BROWN_32).at(13, 0)
    Crafty.e(Components.map.GROUND_DECORATION_32).at(13, 2)
    Crafty.e(Components.map.HERB_SINGLE_32).at(11, 1)
    Crafty.e(Components.map.HERB_TINY_32).at(14, 0)
    Crafty.e(Components.map.HERB_TINY_32).at(14, 1)
    Crafty.e(Components.map.HERBS_TWO_32).at(12, 0)
    Crafty.e(Components.map.HERBS_THREE_32).at(8, 0)
    Crafty.e(Components.map.GROUND_DECORATION_32).at(3, 13)
    Crafty.e(Components.map.HERB_SINGLE_32).at(1, 8)
    Crafty.e(Components.map.HERB_SINGLE_32).at(2, 9)
    Crafty.e(Components.map.HERB_SINGLE_32).at(1, 9)
    Crafty.e(Components.map.HERB_SINGLE_32).at(3, 7)
    Crafty.e(Components.map.GRASS.TOP_LEFT_CORNER).at(0,0)
    Crafty.e(Components.map.GRASS.TOP_RIGHT_CORNER).at(1,0)
    Crafty.e(Components.map.GRASS.BOTTOM_LEFT_CORNER).at(0,1)
    Crafty.e(Components.map.GRASS.BOTTOM_RIGHT_CORNER).at(1,1)
    Crafty.e(Components.map.TREE.TALL_TREE).at(1, 4)
    Crafty.e(Components.map.TREE.TALL_TREE).at(0, 7)
    Crafty.e(Components.map.TREE.TALL_TREE).at(0, 5)
    Crafty.e(Components.map.TREE.TALL_TREE).at(0, 3)
    Crafty.e(Components.map.TREE.TALL_TREE).at(2, 0)
    Crafty.e(Components.map.GRASS.TOP_LEFT_CORNER).at(3,0)
    Crafty.e(Components.map.GRASS.TOP_RIGHT_CORNER).at(4,0)
    Crafty.e(Components.map.GRASS.BOTTOM_LEFT_CORNER).at(3,1)
    Crafty.e(Components.map.GRASS.BOTTOM_RIGHT_CORNER).at(4,1)
    Crafty.e(Components.map.FLOWERS_YELLOW_BIG_128).at(0, 12)
    Crafty.e(Components.map.HERB_LARGE_32).at(3, 2)
    Crafty.e(Components.map.HERB_LARGE_32).at(4, 2)
    Crafty.e(Components.map.HERB_LARGE_32).at(3, 3)
    Crafty.e(Components.map.GRASS.TOP_LEFT_CORNER).at(2,4)
    Crafty.e(Components.map.GRASS.TOP_RIGHT_CORNER).at(3,4)
    Crafty.e(Components.map.GRASS.BOTTOM_LEFT_CORNER).at(2,5)
    Crafty.e(Components.map.GRASS.BOTTOM_RIGHT_CORNER).at(3,5)
    Crafty.e(Components.map.HERB_LARGE_32).at(5, 5)
    Crafty.e(Components.map.HERB_LARGE_32).at(6, 5)
    Crafty.e(Components.map.HERB_LARGE_32).at(6,6)
    Crafty.e(Components.map.HERB_LARGE_32).at(5, 6)
    Crafty.e(Components.map.HERB_LARGE_32).at(5, 6)
    Crafty.e(Components.map.HERB_LARGE_32).at(5, 7)
    Crafty.e(Components.map.HERB_LARGE_32).at(5, 8)
    Crafty.e(Components.map.HERBS_THREE_32).at(7, 5)
    Crafty.e(Components.map.GROUND_DECORATION_32).at(6, 8)
    Crafty.e(Components.map.GROUND_DECORATION_32).at(10, 10)


    Crafty.e(Components.map.SCENE_GO).to(Scenes.game.FOREST_MAP.U1).at(15, 0)

    // Player character, placed at 5, 5 on our grid
    this.player = Crafty.e(Components.map.PLAYER).at(5, 14);
    this.dove = Crafty.e(Components.map.DOVE).at(4, 7);
    this.dove2 = Crafty.e(Components.map.DOVE).at(19, 8);

    this.show_victory = this.bind('VillageVisited', function () {
        if (!Crafty('Village').length) {
            Crafty.scene('Victory');
        }
    });
}, function () {
    this.unbind('VillageVisited', this.show_victory);
});

Crafty.scene('Victory', function () {
    Crafty.e('2D, DOM, Text')
        .attr({ x: 0, y: 0 })
        .text('Victory!');

    this.restart_game = this.bind('KeyDown', function () {
        Crafty.scene('Game');
    });
}, function () {
    this.unbind('KeyDown', this.restart_game);
});

Crafty.scene(Scenes.LOADING, function () {
    // Draw some text for the player to see in case the file
    //  takes a noticeable amount of time to load
    Crafty.e('2D, DOM, Text')
        .text('Loading...')
        .attr({ x: 0, y: Game.height() / 2 - 24, w: Game.width() })
        .css($text_css);

    // Load our sprite map image
    Crafty.load(['assets/forest/outsidebforest.png'], function () {
        // Once the image is loaded...

        // Define the individual sprites in the image
        // Each one (spr_tree, etc.) becomes a component
        // These components' names are prefixed with "spr_"
        //  to remind us that they simply cause the entity
        //  to be drawn with a certain sprite
        Crafty.sprite(32, 'assets/forest/outsidebforest.png', {
            spr_herbs: [11, 0],
            spr_tiny_herb: [0, 11],
            spr_single_herb: [1, 11],
            spr_ground_decoration: [2, 11],
            spr_two_herbs: [10, 0],
            spr_three_herbs: [3, 11],
            spr_medium_herb: [11, 0],
            spr_large_herb: [12, 0],
            spr_large_leaves: [13, 0],
            spr_leaves_white_flowers: [14, 0],
            spr_leaves_yellow_flowers: [15, 0],
            spr_hallow_log_small: [4, 12],
            spr_stump: [4, 11],
            spr_logs: [2, 13],
            spr_hole: [1, 13],
            spr_brown_rocks: [7, 12],
            spr_tall_tree: [5, 11, 1, 2],
            spr_yellow_flowers_big: [5, 7, 3, 2],
            spr_half_green_tree: [11, 12, 1, 2]

        });

        Crafty.sprite(64, 'assets/forest/outsidebforest.png', {
            spr_medium_tree: [0, 7],
            spr_forest_tree: [5, 5],
            spr_medium_tree_light_green: [2, 7],
            spr_medium_tree_dark_green: [4, 7],
            spr_medium_pine: [4, 4]
        });

        // Now that our sprites are ready to draw, start the game
        Crafty.scene(Scenes.menus.MAIN_MENU);
    })
    Crafty.load(['assets/forest/outsidea5forest.png'], function () {
        Crafty.sprite(32, 'assets/forest/outsidea5forest.png', {
            spr_short_grass: [0, 2],
            spr_ledge_top_right_edge: [2, 11],
            spr_ledge_top_edge: [1, 11],
            spr_ledge_right_edge: [2, 12],
            spr_ledge_bottom_right_edge: [2, 13],
            spr_ledge_bottom_edge: [1, 13],
            spr_ledge_bottom_left_edge: [0, 13],
            spr_ledge_left_edge: [0, 12],
            spr_ledge_top_left_edge: [0, 11],
            spr_cliff_right: [2, 14],
            spr_cliff_center: [1, 14],
            spr_cliff_center_bottom: [1, 15],
            spr_cliff_left: [0, 14],
            spr_cliff_left_bottom: [0, 15],
            spr_cliff_right_bottom: [2, 15]
        });
    });

    Crafty.load(['assets/mountain/outsidea2nature.png'], function () {
        Crafty.sprite(32, 'assets/mountain/outsidea2nature.png', {
            spr_grass_middle: [9, 3],
            spr_grass_top_left: [8, 4],
            spr_grass_top_right: [9, 4],
            spr_grass_bottom_left: [8, 5],
            spr_grass_bottom_right: [9, 5],
            spr_dirt_road: [3, 0]
        });
    });

    Crafty.load(['assets/characters/johnson.png'], function () {
        Crafty.sprite(32, 'assets/characters/johnson.png', {
            spr_johnson: [0, 0]
        }, 0, 0);
    });
    Crafty.load(['assets/characters/fight_guy.png'], function () {
        Crafty.sprite(32, 'assets/characters/fight_guy.png', {
            spr_fight_guy: [0, 1]
        }, 0, 0);
    });

    Crafty.load(['assets/characters/dove.png'], function () {
        Crafty.sprite(32, 'assets/characters/dove.png', {
            spr_dove: [0, 0]
        }, 0, 0);
    });

    Crafty.load(["assets/fight/turret.png", "assets/fight/bomb.png", "assets/fight/Bigball.png"], function () {
        Crafty.sprite(65, "assets/fight/turret.png", {
            turret_spr: [0, 0, 1, 0.7846]
        });

        Crafty.sprite(20, "assets/fight/shapes.png", {
            square: [0, 0],
            penta: [1, 0],
            triangle: [2, 0]
        });

        Crafty.sprite(114, "assets/fight/bomb.png", {
            Bomb: [0, 0]
        });

        Crafty.sprite(114, "assets/fight/Bigball.png", {
            BigBall: [0, 0]
        });
    });

    Crafty.load(["assets/fight/ball.png"], function () {
       Crafty.sprite(15, "assets/fight/ball.png", {
           ball_spr: [0,0]
       })
    });

    Crafty.load(["assets/fight/lapachox_log.png"], function () {
        Crafty.sprite(15, "assets/fight/lapachox_log.png", {
            log_projectile: [0,0]
        })
    });

    Crafty.load(["assets/fight/tito_standing.png"], function () {
        Crafty.sprite(64, "assets/fight/tito_standing.png", {
            tito_body_standing: [0,0]
        })
    });

    Crafty.load(["assets/fight/crate_small.jpg"], function () {
        Crafty.sprite(32, "assets/fight/crate_small.jpg", {
            small_crate_spr: [0,0]
        })
    });

    Crafty.load(["assets/fight/tito_cannon.png"], function () {
        Crafty.sprite(64, "assets/fight/tito_cannon.png", {
            tito_canon: [0,0]
        })
    });

    Crafty.load(["assets/fight/lapachox_standing.png"], function () {
        Crafty.sprite(64, "assets/fight/lapachox_standing.png", {
            lapachox_body_standing: [0,0]
        })
    });

    Crafty.load(["assets/fight/lapachox_cannon.png"], function () {
        Crafty.sprite(64, "assets/fight/lapachox_cannon.png", {
            lapachox_canon: [0,0]
        })
    });
});

Crafty.scene(Scenes.menus.MAIN_MENU, function () {
    Crafty.background("url('assets/menu/main-menu-background.png')")
    Crafty.e(Components.menu.MAIN_MENU.NEW_GAME_ITEM)

})

Crafty.scene("Victory", function(){
    var animationImages = ["url('assets/fight/ganarbit1.png')","url('assets/fight/ganarbit2.png')" ]
    var list = new SortedCircularDoublyLinkedList()
    list.insertAll(animationImages)
    var animation = list.head

    var animate = function() {
            Crafty.background(animation.datum)
            animation = animation.next
            window.setTimeout(animate, 700)
    }
    animate()
})

Crafty.scene("Defeat", function(){
    Crafty.background("url('assets/fight/perder.png')")
})


function overAxis(axis) {

    var fixedPosition = function (f) {
        action.fixed = f
        return this;
    }

    var action = {

        initialPos: 0,
        finalPos: 0,
        axis: axis,
        fixed: 0,
        from: function (i) {
            action.initialPos = i
            return this;
        },
        to: function (j) {
            action.finalPos = j;
            return this;
        },
        fixedPosition: fixedPosition,
        x: fixedPosition,
        y: fixedPosition,
        create: function (component) {
            if (action.axis == 'x') {
                for (var i = action.initialPos; i < action.finalPos + 1; i++) {
                    Crafty.e(component).at(i, action.fixed)
                }
            } else if (action.axis == 'y') {
                for (var i = action.initialPos; i < action.finalPos + 1; i++) {
                    Crafty.e(component).at(action.fixed, i)
                }
            }
        }


    }
    return action;
}
