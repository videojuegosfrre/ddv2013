// The Grid component allows an element to be located
//  on a grid of tiles
Components = {}
Components.map = {
    PLAYER: 'PlayerCharacter',
    FIGHT_GUY: 'fightGuy',
    HERBS: 'Herbs',
    HERB_TINY_32: 'HerbTiny',
    HERB_SINGLE_32: 'HerbSingle',
    HERBS_TWO_32: 'HerbsTwo',
    HERBS_THREE_32: 'HerbsThree',
    HERB_MEDIUM_32: 'HerbMedium',
    HERB_LARGE_32: 'HerbLarge',
    LEAVES_LARGE_32: 'LeavesLarge',
    LEAVES_WHITE_FLOWER_32: 'LeavesWhiteFlower',
    LEAVES_YELLOW_FLOWER_32: 'LeavesYellowFlower',
    TREE: {
        TREE_GREEN_64:'TreeMediumGreen',
        TREE_HALF_GREEN_RIGHT_64:'TreeHalfGreenRight',
        TREE_FOREST_64:'TreeForestGreen',
        TREE_LIGHT_GREEN_64: 'TreeMediumLightGreen',
        TREE_DARK_GREEN_64:'TreeMediumDarkGreen',
        TALL_TREE: 'TallTree'
    },
    LEDGE: {
        TOP_LEFT:'TopLeftEdge',
        TOP:'TopEdge',
        TOP_RIGHT:'TopRightEdge',
        RIGHT:'RightEdge',
        BOTTOM_RIGHT:'BottomRightEdge',
        BOTTOM:'BottomEdge',
        BOTTOM_LEFT:'BottomLeftEdge',
        LEFT:'LeftEdge',
        CLIFF_RIGHTMOST: 'CliffRightmost',
        CLIFF_LEFTMOST: 'CliffLeftmost',
        CLIFF_CENTER: 'CliffCenter',
        CLIFF_CENTER_BOTTOM: 'CliffCenterBottom',
        CLIFF_RIGHTMOST_BOTTOM: 'CliffRightmostBottom',
        CLIFF_LEFTMOST_BOTTOM: 'CliffLeftmostBottom'

    },
    PINE_64:'PineMedium',
    GROUND_DECORATION_32:'GroundDecoration',
    FLOWERS_YELLOW_32: 'FlowersYellow',
    FLOWERS_WHITE_32: 'FlowersWhite',
    FLOWERS_RED_32:'FlowersRed',
    FLOWERS_YELLOW_BIGGER_32:'FlowersYellowBigger',
    FLOWERS_YELLOW_BIG_128:'FlowersYellowBig',
    STUMP_32:'Stump',
    LOG_HOLLOW_32:'LogHollow',
    LOG_HOLLOW_GREEN_64:'LogHollowGreenLarge',
    LOG_HOLLOW_BROWN_64:'LogHollowBrownLarge',
    HOLE_32:'Hole',
    LOGS_32:'Logs',
    VEGGETABLES_WHITE_32:'VeggetablesWhite',
    VEGGETABLES_TOMATO_32:'VeggetablesTomato',
    VEGGETABLES_LEAVES_32:'VeggetablesLeaves',
    VEGGETABLES_LETTUCE_32:'VeggetablesLettuce',
    ROCK_32_GREEN_32:'RockGreen',
    ROCK_32_WHITE_32:'RockWhite',
    ROCK_32_WHITE_ALTERNATIVE_32:'RockWhiteAlternative',
    ROCK_32_BROWN_32:'RockBrown',
    ROCK_32_BROWN_ALTERNATIVE_32:'RockBrownAlternative',
    SCARECROW:'Scarecrow',
    STONES:'Stones',
    GRASS: {
        TOP_LEFT_CORNER:'GrassTopLeftCorner',
        TOP_RIGHT_CORNER:'GrassTopRightCorner',
        BOTTOM_LEFT_CORNER:'GrassBottomLeftCorner',
        BOTTOM_RIGHT_CORNER:'GrassBottomRightCorner',
        MIDDLE:'GrassMiddle',
        SHORT_GRASS: 'GrassShort'
    },
    SCENE_GO: 'GoToScene',
    DOVE: 'Dove',
    DIRT: {
        ROAD: 'DirtRoad'
    }
}

Crafty.c('Grid', {
    init: function() {
        this.attr({
            w: Game.map_grid.tile.width,
            h: Game.map_grid.tile.height
        })
    },


    size: function(widthInGrids, heightInGrids) {
        this.attr({
            w: Game.map_grid.tile.width * widthInGrids,
            h: Game.map_grid.tile.height * heightInGrids
        })
    },

    sizeInPixels:function(width, height){
        this.attr({
            h: height,
            w: width
        })
    },

    // Locate this entity at the given position on the grid
    at: function(x, y) {
        if (x === undefined && y === undefined) {
            return { x: this.x/Game.map_grid.tile.width, y: this.y/Game.map_grid.tile.height }
        } else {
            this.attr({ x: x * Game.map_grid.tile.width, y: y * Game.map_grid.tile.height });
            return this;
        }
    }
});

// An "Actor" is an entity that is drawn in 2D on canvas
//  via our logical coordinate grid
Crafty.c('Actor', {
    init: function() {
        this.requires('2D, Canvas, Grid');
    }
});

Crafty.c(Components.map.SCENE_GO, {
    init: function() {
        this.requires('Actor,Grid');
    },

    to: function(sceneName){
        this.attr({scene: sceneName})
        return this
    },

    visit: function() {
        Crafty.scene(this.scene)
    }
});

// Small templates
Crafty.c('Tree', {
    init: function() {
        this.requires('Actor,Solid,spr_herbs');
    }
});
Crafty.c(Components.map.HERB_TINY_32, {
    init: function() {
        this.requires('Actor,Solid,spr_tiny_herb');
    }
});
Crafty.c(Components.map.HERB_SINGLE_32, {
    init: function() {
        this.requires('Actor,Solid,spr_single_herb');
    }
});
Crafty.c(Components.map.GROUND_DECORATION_32, {
    init: function() {
        this.requires('Actor,spr_ground_decoration');
    }
});
Crafty.c(Components.map.HERBS_TWO_32, {
    init: function() {
        this.requires('Actor,Solid,spr_two_herbs');
    }
});
Crafty.c(Components.map.HERBS_THREE_32, {
    init: function() {
        this.requires('Actor,Solid,spr_three_herbs');
    }
});
Crafty.c(Components.map.HERB_MEDIUM_32, {
    init: function() {
        this.requires('Actor,Solid,spr_medium_herb');
    }
});
Crafty.c(Components.map.HERB_LARGE_32, {
    init: function() {
        this.requires('Actor,Solid,spr_large_herb');
    }
});
Crafty.c(Components.map.LEAVES_LARGE_32, {
    init: function() {
        this.requires('Actor,Solid,spr_large_leaves');
    }
});
Crafty.c(Components.map.LEAVES_WHITE_FLOWER_32, {
    init: function() {
        this.requires('Actor,Solid,spr_leaves_white_flowers');
    }
});
Crafty.c(Components.map.LEAVES_YELLOW_FLOWER_32, {
    init: function() {
        this.requires('Actor,Solid,spr_leaves_yellow_flowers');
    }
});
Crafty.c(Components.map.GRASS.SHORT_GRASS, {
    init: function() {
        this.requires('Actor,spr_short_grass');
    }
});
Crafty.c(Components.map.GRASS.MIDDLE, {
    init: function() {
        this.requires('Actor,spr_grass_middle');
    }
});
Crafty.c(Components.map.GRASS.TOP_LEFT_CORNER, {
    init: function() {
        this.requires('Actor,spr_grass_top_left');
    }
});
Crafty.c(Components.map.GRASS.TOP_RIGHT_CORNER, {
    init: function() {
        this.requires('Actor,spr_grass_top_right');
    }
});
Crafty.c(Components.map.GRASS.BOTTOM_LEFT_CORNER, {
    init: function() {
        this.requires('Actor,spr_grass_bottom_left');
    }
});
Crafty.c(Components.map.GRASS.BOTTOM_RIGHT_CORNER, {
    init: function() {
        this.requires('Actor,spr_grass_bottom_right');
    }
});
Crafty.c(Components.map.LOG_HOLLOW_32, {
    init: function() {
        this.requires('Actor,Solid,spr_hallow_log_small');
    }
});
Crafty.c(Components.map.STUMP_32, {
    init: function() {
        this.requires('Actor,Solid,spr_stump');
    }
});
Crafty.c(Components.map.LOGS_32, {
    init: function() {
        this.requires('Actor,Solid,spr_logs');
    }
});

Crafty.c(Components.map.TREE.TALL_TREE, {
    init: function() {
        this.requires('Actor,Solid,spr_tall_tree');
    }
});

Crafty.c(Components.map.LEDGE.TOP_LEFT, {
    init: function() {
        this.requires('Actor,Solid,spr_ledge_top_left_edge');
    }
});
Crafty.c(Components.map.LEDGE.TOP, {
    init: function() {
        this.requires('Actor,Solid,spr_ledge_top_edge');
    }
});

Crafty.c(Components.map.LEDGE.TOP_RIGHT, {
    init: function() {
        this.requires('Actor,Solid,spr_ledge_top_right_edge');
    }
});

Crafty.c(Components.map.FIGHT_GUY, {
    init: function() {
        this.requires('Actor,spr_fight_guy');
    }
});

Crafty.c(Components.map.LEDGE.RIGHT, {
    init: function() {
        this.requires('Actor,Solid,spr_ledge_right_edge');
    }
});

Crafty.c(Components.map.LEDGE.BOTTOM_RIGHT, {
    init: function() {
        this.requires('Actor,Solid,spr_ledge_bottom_right_edge');
    }
});

Crafty.c(Components.map.LEDGE.BOTTOM, {
    init: function() {
        this.requires('Actor,Solid,spr_ledge_bottom_edge');
    }
});

Crafty.c(Components.map.LEDGE.BOTTOM_LEFT, {
    init: function() {
        this.requires('Actor,Solid,spr_ledge_bottom_left_edge');
    }
});

Crafty.c(Components.map.LEDGE.LEFT, {
    init: function() {
        this.requires('Actor,Solid,spr_ledge_left_edge');
    }
});

Crafty.c(Components.map.HOLE_32, {
    init: function() {
        this.requires('Actor,Solid,spr_hole');
    }
});
Crafty.c(Components.map.LEDGE.CLIFF_RIGHTMOST, {
    init: function() {
        this.requires('Actor,Solid,spr_cliff_right');
    }
});
Crafty.c(Components.map.LEDGE.CLIFF_RIGHTMOST_BOTTOM, {
    init: function() {
        this.requires('Actor,Solid,spr_cliff_right_bottom');
    }
});

Crafty.c(Components.map.LEDGE.CLIFF_LEFTMOST, {
    init: function() {
        this.requires('Actor,Solid,spr_cliff_left');
    }
});

Crafty.c(Components.map.LEDGE.CLIFF_CENTER, {
    init: function() {
        this.requires('Actor,Solid,spr_cliff_center');
    }
});

Crafty.c(Components.map.LEDGE.CLIFF_CENTER_BOTTOM, {
    init: function() {
        this.requires('Actor,Solid,spr_cliff_center_bottom');
    }
});

Crafty.c(Components.map.LEDGE.CLIFF_LEFTMOST_BOTTOM, {
    init: function() {
        this.requires('Actor,Solid,spr_cliff_left_bottom');
    }
});

Crafty.c(Components.map.ROCK_32_BROWN_32, {
    init: function() {
        this.requires('Actor,Solid,spr_brown_rocks');
    }
});
Crafty.c(Components.map.DIRT.ROAD, {
    init: function() {
        this.requires('Actor,spr_dirt_road');
    }
});

Crafty.c(Components.map.FLOWERS_YELLOW_BIG_128, {
    init: function() {
        this.requires('Actor,spr_yellow_flowers_big');
    }
});

//2x2
Crafty.c(Components.map.TREE.TREE_GREEN_64, {
    init: function() {
        this.requires('Actor,Solid,spr_medium_tree');
        this.size(2,2)
    }
});
Crafty.c(Components.map.TREE.TREE_HALF_GREEN_RIGHT_64, {
    init: function() {
        this.requires('Actor,Solid,spr_half_green_tree');
        this.size(1,2)
    }
});
Crafty.c(Components.map.TREE.TREE_FOREST_64, {
    init: function() {
        this.requires('Actor,Solid,spr_forest_tree');
        this.size(2,2)
    }
});

Crafty.c(Components.map.TREE.TREE_LIGHT_GREEN_64, {
    init: function() {
        this.requires('Actor,Solid,spr_medium_tree_light_green');
        this.size(2,2)
    }
});
Crafty.c(Components.map.TREE.TREE_DARK_GREEN_64, {
    init: function() {
        this.requires('Actor,Solid,spr_medium_tree_dark_green');
        this.size(2,2)
    }
});
Crafty.c(Components.map.PINE_64, {
    init: function() {
        this.requires('Actor,Solid,spr_medium_pine');
        this.size(2,2)
    }
});

// A Bush is just an Actor with a certain color
Crafty.c('Bush', {
    init: function() {
        this.requires('Actor, Color, Solid')
            .color('rgb(20, 185, 40)');
    }
});

Crafty.c(Components.map.PLAYER, {
    init: function() {
        this.requires('Actor, Fourway, spr_johnson, Collision, SpriteAnimation')
            .fourway(2)
            .stopOnSolids()
            .onHit(Components.map.SCENE_GO, this.visitPlace)
            .animate('PlayerMovingUp',    0, 3, 3)
            .animate('PlayerMovingRight', 0, 2, 3)
            .animate('PlayerMovingDown',  0, 0, 3)
            .animate('PlayerMovingLeft',  0, 1, 3);

        var animation_speed = 20;
        this.bind('NewDirection', function(data) {
            if (data.x > 0) {
                this.animate('PlayerMovingRight', animation_speed, -1);
            } else if (data.x < 0) {
                this.animate('PlayerMovingLeft', animation_speed, -1);
            } else if (data.y > 0) {
                this.animate('PlayerMovingDown', animation_speed, -1);
            } else if (data.y < 0) {
                this.animate('PlayerMovingUp', animation_speed, -1);
            } else {
                this.stop();
            }
        });
    },

    stopOnSolids: function() {
        this.onHit('Solid', this.stopMovement);

        return this;
    },

    // Stops the movement
    stopMovement: function() {
        this._speed = 0;
        if (this._movement) {
            this.x -= this._movement.x;
            this.y -= this._movement.y;
        }
    },

    visitPlace: function(data) {
        var place = data[0].obj;
        place.visit()
    }
});

Crafty.c("Animal", {
    init: function(){
        this.requires('Actor, Collision, SpriteAnimation')
            .animate('AnimalMovingUp',    0, 3, 1)
            .animate('AnimalMovingRight', 0, 2, 1)
            .animate('AnimalMovingDown',  0, 0, 1)
            .animate('AnimalMovingLeft',  0, 1, 1)
        var animation_speed = 20
        var self = this

    }


})

Crafty.c(Components.map.DOVE, {
    init: function() {
        this.requires('Actor,spr_dove, Collision, SpriteAnimation')
            .animate('DoveMovingUp',    0, 3, 1)
            .animate('DoveMovingRight', 0, 2, 1)
            .animate('DoveMovingDown',  0, 0, 1)
            .animate('DoveMovingLeft',  0, 1, 1);

        var animation_speed = 20;
        var self = this

        var timesLeft = 32


        this.moveRight = function() {
            if (timesLeft > 0) {
                self.x += 1
                timesLeft--
                setTimeout(self.moveRight, 40)
            } else {
                timesLeft = 32
            }
        }

        this.moveLeft = function() {
            if (timesLeft > 0) {
                self.x -= 1
                timesLeft--
                setTimeout(self.moveLeft, 40)
            } else {
                timesLeft = 32
            }
        }

        this.moveUp = function() {
            if (timesLeft > 0) {
                self.y -= 1
                timesLeft--
                setTimeout(self.moveUp, 40)
            } else {
                timesLeft = 32
            }
        }

        this.moveDown = function() {
            if (timesLeft > 0) {
                self.y += 1
                timesLeft--
                setTimeout(self.moveDown, 40)
            } else {
                timesLeft = 32
            }
        }



        var moveDoveRandomly = function(delay){
            delay = delay || 2000
            setTimeout(function(){
                var dir = getRandomInt(0,3);
                if (dir == 0) {
                    setTimeout(self.moveRight,500)
                    self.animate('DoveMovingRight', animation_speed, -1);
                } else if (dir == 1) {
                    setTimeout(self.moveLeft,500)
                    self.animate('DoveMovingLeft', animation_speed, -1);
                } else if (dir == 2) {
                    setTimeout(self.moveDown,500)
                    self.animate('DoveMovingDown', animation_speed, -1);
                } else if (dir == 3) {
                    setTimeout(self.moveUp,500)
                    self.animate('DoveMovingUp', animation_speed, -1);
                }
                animation_speed += 20
                moveDoveRandomly()
            },delay)
        }

        moveDoveRandomly(1)

        console.log("dove started")

    },

    stopOnSolids: function() {
        this.onHit('Solid', this.stopMovement);

        return this;
    },

    // Stops the movement
    stopMovement: function() {
        this._speed = 0;
        if (this._movement) {
            this.x -= this._movement.x;
            this.y -= this._movement.y;
        }
    },

    visitPlace: function(data) {
        var place = data[0].obj;
        place.visit()
    }
});

Crafty.c('Village', {
    init: function() {
        this.requires('Actor, Color')
            .color('rgb(170, 125, 40)');
    },

    collect: function() {
        this.destroy();
    }
});

//MENU
Components.menu = {
    GAME_TITLE: 'GameTitle',
    MAIN_MENU: {
      ITEM: 'MenuItem',
      NEW_GAME_ITEM: 'NewGameMenuItem'
    }
}

Crafty.c(Components.menu.MAIN_MENU.ITEM, {
    init : function() {
        this.addComponent("2D, DOM, Mouse");
        this.attr({
            w : 240,
            h : 40,
            x : 237
        });
        this.css("z-index", "0");
        this.css("cursor", "pointer");
        this.bind("Click", function() {
            Crafty.audio.play("click");
        });
    }
});

Crafty.c(Components.menu.MAIN_MENU.NEW_GAME_ITEM, {
    init : function() {
        this.addComponent("MenuItem");
        this.attr({
            y : 185,
            x: 350
        });
        this.bind("Click", function() {
            this.css("background-position", "-480px 0");
            Crafty.scene(Scenes.game.FOREST_MAP.INITIAL)
        });
    }
});