Crafty.scene(Scenes.game.fights.FIRST_STAGE.name, function () {
    Crafty.background("url('assets/fight/tropical_fight.jpg')")
    currentShape = false
    goBackward = false

    Scenes.game.fights.FIRST_STAGE.nextTurn = function () {

    }
    var stage_w = 1500,
        stage_h = Game.height(),
        canvas_w = Game.width(),
        canvas_h = Game.height(),
        HW = canvas_w / 2,
        HH = canvas_h / 2,
        text,

        canShot = false,
        increasePower = false,
        speed,
        PBar,
        rotation = 0,
        numOfSquares,
        numOfTriangles,
        numOfPentagons,
        floor,
        squareBTN,
        pentBTN,
        triangleBTN,
        selectedShape;
    Crafty.ctx = this
    var world = Crafty.box2D.world;
    numOfSquares = 3,
        numOfTriangles = 2,
        numOfPentagons = 2
    var robots = []

    floor = Crafty.e("2D, Canvas, Color, Box2D, floor")
        .attr({ x: 0, y: stage_h - 4, w: stage_w, h: 4})
        .color("#000")
        .box2d(
        {
            bodyType: 'static',
            density: 1.0,
            friction: 10000,
            restitution: 0

        }
    );
    Scenes.game.fights.FIRST_STAGE.floor = floor

    var copy = Crafty.e("2D, DOM, Text")
        .attr({ x: HW - 230, y: 0, w: Game.width()})
        .textFont({ size: '20px', weight: 'bold'})
        .textColor('#FFFFFF', 100)
        .text(TEXT.FIGHT_COMMON.SHOOTING_INSTRUCTION);

    PBar = Crafty.e("Canvas, PowerBar")

    playerLife = Crafty.e("LifeBar").at(30, 40)
    playerLife.life(200)

    AILife = Crafty.e("LifeBar").at(500, 40)
    AILife.life(200)

    playerRobot = Crafty.e("RobotTito")
    playerRobot.at(35, stage_h)
    playerRobot.playerControlled(true)
    playerRobot.turret.addWeapon('TitoWeapon', Crafty.e('TitoWeapon'))

    AIRobot = Crafty.e("RobotLapachox")
    AIRobot.at(stage_w - 300, stage_h)
    AIRobot.turret.addWeapon('LogWeapon', Crafty.e('LogWeapon'))
    AIRobot.turret.setSelectedWeapon('LogWeapon')

    robots.push(playerRobot)
    robots.push(AIRobot)

    Scenes.game.fights.FIRST_STAGE.robots = new SortedCircularDoublyLinkedList()
    Scenes.game.fights.FIRST_STAGE.robots.insertAll(robots)
    Scenes.game.fights.FIRST_STAGE.activeNode = Scenes.game.fights.FIRST_STAGE.robots.head
    Scenes.game.fights.FIRST_STAGE.activeRobot = Scenes.game.fights.FIRST_STAGE.activeNode.datum
    Scenes.game.fights.FIRST_STAGE.nextTurn = function () {
        Scenes.game.fights.FIRST_STAGE.activeNode = Scenes.game.fights.FIRST_STAGE.activeNode.next
        Scenes.game.fights.FIRST_STAGE.activeRobot = Scenes.game.fights.FIRST_STAGE.activeNode.datum
        Scenes.game.fights.FIRST_STAGE.start_turn = true
    }

    crate = Crafty.e("WoodenCrate").at(140, stage_h)
    crate = Crafty.e("WoodenCrate").at(300, stage_h)
    crate = Crafty.e("WoodenCrate").at(340, stage_h)
    crate = Crafty.e("WoodenCrate").at(382, stage_h)
    crate = Crafty.e("WoodenCrate").at(382, stage_h - 32)
    crate = Crafty.e("WoodenCrate").at(382, stage_h - 64)
    crate = Crafty.e("WoodenCrate").at(382, stage_h - 96)
    crate = Crafty.e("WoodenCrate").at(382, stage_h - 128)
    crate = Crafty.e("WoodenCrate").at(382, stage_h - 160)
    crate = Crafty.e("WoodenCrate").at(382, stage_h - 192)
    crate = Crafty.e("WoodenCrate").at(500, stage_h)
    crate = Crafty.e("WoodenCrate").at(534, stage_h)
    crate = Crafty.e("WoodenCrate").at(568, stage_h)
    crate = Crafty.e("WoodenCrate").at(568 + 34, stage_h)
    crate = Crafty.e("WoodenCrate").at(524, stage_h - 32)
    crate = Crafty.e("WoodenCrate").at(524 + 34, stage_h - 32)
    crate = Crafty.e("WoodenCrate").at(558 + 34, stage_h - 32)
    crate = Crafty.e("WoodenCrate").at(558 + 34, stage_h - 64)
    crate = Crafty.e("WoodenCrate").at(510, stage_h - 64)
    crate = Crafty.e("WoodenCrate").at(650, stage_h)
    crate = Crafty.e("WoodenCrate").at(650, stage_h - 32)
    crate = Crafty.e("WoodenCrate").at(650, stage_h - 64)
    crate = Crafty.e("WoodenCrate").at(682, stage_h)
    crate = Crafty.e("WoodenCrate").at(682, stage_h - 32)
    crate = Crafty.e("WoodenCrate").at(682, stage_h - 64)
    crate = Crafty.e("WoodenCrate").at(682, stage_h - 96)
    crate = Crafty.e("WoodenCrate").at(1286, stage_h)
    crate = Crafty.e("WoodenCrate").at(1286, stage_h + 32)
    crate = Crafty.e("WoodenCrate").at(1386, stage_h)
    crate = Crafty.e("WoodenCrate").at(1420, stage_h)
    crate = Crafty.e("WoodenCrate").at(1420, stage_h-32)
    crate = Crafty.e("WoodenCrate").at(1420, stage_h-64)
    crate = Crafty.e("WoodenCrate").at(1420, stage_h-96)
    crate = Crafty.e("WoodenCrate").at(1420, stage_h-128)
    crate = Crafty.e("WoodenCrate").at(1420, stage_h-192)
    /*

     var stonehenge = Crafty.e("2D, Canvas, Color, Box2D")
     .attr({ x: stage_w - 800, y: stage_h - 100, w: 20, h: 100})
     .color("#000")
     .box2d(
     {
     bodyType: 'dynamic',
     density: 20.0,
     friction: 10,
     restitution: 0

     }
     );

     stonehenge = Crafty.e("2D, Canvas, Color, Box2D")
     .attr({ x: stage_w - 900, y: stage_h - 100, w: 20, h: 100})
     .color("#000")
     .box2d(
     {
     bodyType: 'dynamic',
     density: 20.0,
     friction: 10,
     restitution: 0

     }
     );

     stonehenge = Crafty.e("2D, Canvas, Color, Box2D")
     .attr({ x: stage_w - 915, y: stage_h - 110, w: 150, h: 10})
     .color("#000")
     .box2d(
     {
     bodyType: 'dynamic',
     density: 8.0,
     friction: 10,
     restitution: 0

     }
     );
     */

/*

    squareBTN = Crafty.e("2D, Canvas, Mouse, squareOut")
        .attr({ x: HW - 145, y: HH - 57})
        .bind('MouseOver',
        function () {
            this.sprite(1, 0);
            text.text(TEXT.FIGHT_COMMON.BOXES_REMAINING.format(numOfSquares));
        })
        .bind('MouseOut',
        function () {
            this.sprite(0, 0);
            text.text(TEXT.FIGHT_COMMON.PICK_A_WEAPON);
        })
        .bind('Click',
        function () {
            if (numOfSquares > 0) {
                hideBTNS();
                selectedShape = 1;
                playerRobot.activate();
                numOfSquares--;
            }
        });
*/


    pentBTN = Crafty.e("2D, Canvas, Mouse, Bomb")
        .attr({ x: HW - 125, y: HH - 67})
        .bind('MouseOver',
        function () {
            text.text(TEXT.FIGHT_COMMON.PEPPERONI_REMAINING.format(0));
        })
        .bind('MouseOut',
        function () {
            text.text(TEXT.FIGHT_COMMON.PICK_A_WEAPON);
        })
        .bind('Click',
        function () {
            alert("Arma no implementada.")
        });

    triangleBTN = Crafty.e("2D, Canvas, Mouse, BigBall")
        .attr({ x: HW - 30, y: HH - 57})
        .bind('MouseOver',
        function () {
            text.text(TEXT.FIGHT_COMMON.PIZZAS_REMAINING.format(playerRobot.turret.getWeapon('TitoWeapon').ammo()));
        })
        .bind('MouseOut',
        function () {
            text.text(TEXT.FIGHT_COMMON.PICK_A_WEAPON);
        })
        .bind('Click',
        function () {
            if (playerRobot.turret.getWeapon('TitoWeapon').ammo() > 0) {
                hideBTNS();
                playerRobot.turret.setSelectedWeapon('TitoWeapon')
                playerRobot.activate()
            }
        });

    text = Crafty.e("2D, DOM, Text")
        .attr({ x: HW - 125, y: HH + 60, w: 250})
        .textFont({ size: '20px', weight: 'bold' })
        .text("Elige un arma")
        .textColor("#ffffff");



    var hideBTNS = function () {
        pentBTN.visible = false;
        triangleBTN.visible = false;
        text.visible = false;
    }

    var showBTNS = function () {
            pentBTN.visible = true;
            triangleBTN.visible = true;
            text.visible = true;
    }


    var destroyWorld = function () {
        for (var b = world.GetBodyList(); b; b = b.GetNext()) {
            world.DestroyBody(b);
        }
    }

    var onMouseMove = function (e) {
        if (playerRobot.isActivated) {
            playerRobot.rotateTurret(e.clientX, e.clientY)
        }
    }
    var onDown = function (e) {
        if (playerRobot.isActivated) {
            increasePower = true;
        }
    }
    var onUp = function (e) {
        if (playerRobot.isActivated) {
            increasePower = false;
            playerRobot.fire();
        }
    }

    var timer;
    onEnterFrame = function () {
        if (!Scenes.game.fights.FIRST_STAGE.activeRobot.isAlive()) {
            if (Scenes.game.fights.FIRST_STAGE.activeRobot.playerControlled()) {
                Crafty.scene("Defeat")
            } else {
                Crafty.scene("Victory")
            }
        }
        if (increasePower === true) {
            playerRobot.increaseTurretPower()
            PBar.powerBar(playerRobot.turret.currentPower);
        }
        if (currentShape) {
            if (Scenes.game.fights.FIRST_STAGE.activeRobot.turret.facingRight) {
                var vpx = (currentShape._x - HW)

                //Max x in map * 32 - Crafty.viewport.width = 1164
                if (vpx > 300) {
                    if (Crafty.viewport.x > -740) {
                        Crafty.viewport.x -= 20;
                    }
                }
            } else {
                var vpx = (HW - currentShape._x)

                //Max x in map * 32 - Crafty.viewport.width = 1164
                if (vpx < 300) {
                    if (Crafty.viewport.x < 0) {
                        Crafty.viewport.x += 20;
                    }
                }
            }

        }

        if (goBackward) {
            if (Crafty.viewport.x < 0) {
                Crafty.viewport.x += 10;
            } else {
                goBackward = false;
            }
        }

        if (Scenes.game.fights.FIRST_STAGE.start_turn) {
            if (Scenes.game.fights.FIRST_STAGE.activeRobot.playerControlled()) {
                playerLife.life(playerRobot.hitPoints)
                Scenes.game.fights.FIRST_STAGE.start_turn = false
                showBTNS()
            } else {
                if (currentShape) {
                    currentShape = null
                }
                if (Crafty.viewport.x > -760) {
                    Crafty.viewport.x -= 20;
                    timer = 0
                } else {
                    if (timer < 30) {
                        timer++
                    } else {
                        AILife.life(AIRobot.hitPoints)
                        Scenes.game.fights.FIRST_STAGE.start_turn = false
                        Scenes.game.fights.FIRST_STAGE.activeRobot.activate()
                    }
                }
            }
        }
    }
    Crafty.addEvent(Crafty.ctx, "mousemove", onMouseMove);
    Crafty.addEvent(Crafty.ctx, "mousedown", onDown);
    Crafty.addEvent(Crafty.ctx, "mouseup", onUp);
    Crafty.bind("EnterFrame", onEnterFrame);


}, function(){
    Crafty.unbind("EnterFrame", onEnterFrame);
});